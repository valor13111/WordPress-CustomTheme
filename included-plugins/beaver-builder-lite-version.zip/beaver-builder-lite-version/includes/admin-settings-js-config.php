<script type="text/javascript">

FLBuilderAdminSettingsStrings = {
	selectFile: '<?php esc_attr_e('Select File', 'fl-builder'); ?>',
	uninstall: '<?php esc_attr_e('Please type "uninstall" in the box below to confirm that you really want to uninstall the page builder and all of its data.', 'fl-builder'); ?>'
};

</script>